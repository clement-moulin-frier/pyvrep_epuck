try:
    from .contact import ContactSensor
except ImportError:
    pass
