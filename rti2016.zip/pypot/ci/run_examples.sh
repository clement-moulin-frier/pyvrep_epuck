#!/bin/bash
set -x

# TODO
# ipython nbconvert --to python *.ipynb