Pypot development started in mid 2012 at Inria Flowers, Bordeaux - France. Main authors are (and/or have been):

* Pierre Rouanet
* Steve N'Guyen
* Matthieu Lapeyre

People who have contributed to Pypot:

* Rémi Barraquand
* Haylee Fogg
