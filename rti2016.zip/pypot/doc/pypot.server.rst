:mod:`server` Package
=====================

.. automodule:: pypot.server
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`rest` Module
---------------------

.. automodule:: pypot.server.rest
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`httpserver` Module
------------------------

.. automodule:: pypot.server.httpserver
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`zmqserver` Module
-----------------------

.. automodule:: pypot.server.zmqserver
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`snap` Module
-----------------------

.. automodule:: pypot.server.snap
    :members:
    :undoc-members:
    :show-inheritance:
