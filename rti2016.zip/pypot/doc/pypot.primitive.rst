:mod:`primitive` Package
========================


:mod:`~pypot.primitive.primitive` Module
----------------------------------------

.. automodule:: pypot.primitive.primitive
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`~pypot.primitive.manager` Module
--------------------------------------

.. automodule:: pypot.primitive.manager
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`~pypot.primitive.move` Module
------------------------------------

.. automodule:: pypot.primitive.move
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`~pypot.primitive.utils` Module
------------------------------------

.. automodule:: pypot.primitive.utils
    :members:
    :undoc-members:
    :show-inheritance: